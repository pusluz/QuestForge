# QuestForge

A mod manager that runs on a Meta Quest headset. It talks to the headset's own Wireless debugging
service, so it can reach other games' data folders, back them up, apply mods, and edit saves.

## Build (GitHub Actions)
1. Push this folder to a GitHub repo (keep the folder structure).
2. Open the repo's **Actions** tab, then the latest **Build APK** run.
3. Download **QuestForge-debug-apk** from Artifacts, unzip, and sideload the `.apk`.

If the build fails, open the failed step's log and send it over.

## First run on the headset
1. Developer Mode on (Meta Horizon phone app).
2. Headset Settings, System, Developer, switch on **Wireless debugging** (on Wi-Fi).
3. In QuestForge open **Setup**, tap **Pair device with pairing code** on the headset, and enter the
   popup's port and 6-digit code. Pair once. Then **Connect** (or **Auto-connect**).

## Mod zip layout
```
my-mod.zip
  mod.json                optional: {"name","version","author","description","target":"com.studio.game"}
  data/files/Save.json    -> /sdcard/Android/data/<target>/files/Save.json
  obb/main.1.com.x.obb    -> /sdcard/Android/obb/<target>/main.1.com.x.obb
```
Without `mod.json`, the mod targets the game you picked on Home.

## Safety net
Every file is backed up to `/sdcard/QuestForge/backups/<package>/` before it is changed.
**Remove all mods** puts the originals back. Backups survive uninstalling QuestForge.

## Store index (optional)
Settings, Store address: an https link to JSON like
`[{"id":"a","name":"Mod","author":"you","version":"1.0","description":"...","url":"a.zip"}]`
(relative `url` values resolve against the index address).

## Limits
- Edits files in data/obb folders. It does not patch an APK's code or game memory.
- Server-side stats in online games can't be changed, and online games can ban modified files.
- Zip only (no 7z/rar).
