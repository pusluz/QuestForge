package com.teahack.questforge

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

enum class Kind { Bool, Whole, Decimal, Text }

data class JsonField(
    val path: List<Any>,
    val label: String,
    val value: String,
    val orig: String,
    val kind: Kind,
)

private const val MAX_FIELDS = 5000

private fun flattenJson(
    node: Any?,
    path: List<Any> = emptyList(),
    out: MutableList<JsonField> = mutableListOf(),
): MutableList<JsonField> {
    if (out.size >= MAX_FIELDS) return out
    val label = path.joinToString(" › ")
    when (node) {
        is JSONObject -> {
            val keys = node.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                flattenJson(node.opt(k), path + k, out)
            }
        }
        is JSONArray -> for (i in 0 until node.length()) flattenJson(node.opt(i), path + i, out)
        is Boolean -> out += JsonField(path, label, node.toString(), node.toString(), Kind.Bool)
        is Int, is Long -> out += JsonField(path, label, node.toString(), node.toString(), Kind.Whole)
        is Double, is Float -> out += JsonField(path, label, node.toString(), node.toString(), Kind.Decimal)
        is String -> out += JsonField(path, label, node, node, Kind.Text)
    }
    return out
}

/** An open file: raw text, plus a field-by-field view when the file is JSON. */
class EditorState(val path: String, text: String) {
    var raw by mutableStateOf(text)
    var rawMode by mutableStateOf(true)
    val fields = mutableStateListOf<JsonField>()
    private var root: Any? = null
    val jsonCapable: Boolean

    init {
        jsonCapable = parseFields()
    }

    /** Re-read the raw text as JSON. Returns false if it isn't valid JSON. */
    fun parseFields(): Boolean {
        val v = runCatching { JSONTokener(raw).nextValue() }.getOrNull()
        if (v !is JSONObject && v !is JSONArray) return false
        root = v
        fields.clear()
        fields.addAll(flattenJson(v))
        rawMode = false
        return true
    }

    fun enterRaw() {
        render()?.let { raw = it }
        rawMode = true
    }

    /** The text to write back, or null if a number field holds something that isn't a number. */
    fun render(): String? {
        if (rawMode) return raw
        val r = root ?: return raw
        for (f in fields) {
            if (f.value == f.orig) continue
            val v: Any = when (f.kind) {
                Kind.Bool -> when (f.value.trim().lowercase()) {
                    "true" -> true
                    "false" -> false
                    else -> return null
                }
                Kind.Whole -> f.value.trim().toLongOrNull() ?: return null
                Kind.Decimal -> f.value.trim().toDoubleOrNull() ?: return null
                Kind.Text -> f.value
            }
            var cur: Any = r
            for (k in f.path.dropLast(1)) {
                cur = if (cur is JSONObject) cur.get(k as String) else (cur as JSONArray).get(k as Int)
            }
            val last = f.path.last()
            if (cur is JSONObject) cur.put(last as String, v) else (cur as JSONArray).put(last as Int, v)
        }
        return if (r is JSONObject) r.toString(2) else (r as JSONArray).toString(2)
    }
}
