package com.teahack.questforge

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap

enum class Dest(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Filled.Home),
    Library("Mods", Icons.Filled.Menu),
    Store("Store", Icons.Filled.Search),
    Editor("Editor", Icons.Filled.Edit),
    Setup("Setup", Icons.Filled.Build),
    Settings("Settings", Icons.Filled.Settings),
}

private val Connected = Color(0xFF3DDC97)

// ---- shell: navigation rail on the headset panel, bottom bar on narrow screens ---------------

@Composable
fun QuestForgeApp(vm: AppViewModel) {
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
    var dest by rememberSaveable { mutableStateOf(Dest.Home) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importMod(uri)
    }
    val upload = {
        picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
    }
    val wide = LocalConfiguration.current.screenWidthDp >= 720

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            if (!wide) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    Dest.values().forEach { d ->
                        NavigationBarItem(
                            selected = dest == d,
                            onClick = { dest = d },
                            icon = { Icon(d.icon, d.label) },
                            label = { Text(d.label, maxLines = 1) },
                        )
                    }
                }
            }
        },
    ) { pad ->
        Row(Modifier.padding(pad).fillMaxSize()) {
            if (wide) {
                NavigationRail(containerColor = MaterialTheme.colorScheme.surface) {
                    Spacer(Modifier.height(12.dp))
                    Dest.values().forEach { d ->
                        NavigationRailItem(
                            selected = dest == d,
                            onClick = { dest = d },
                            icon = { Icon(d.icon, d.label) },
                            label = { Text(d.label) },
                        )
                    }
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight()) {
                vm.busy?.let { label ->
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Muted(label, Modifier.padding(horizontal = 24.dp, vertical = 4.dp))
                }
                Box(Modifier.weight(1f)) {
                    when (dest) {
                        Dest.Home -> HomeScreen(vm, { dest = it }, upload)
                        Dest.Library -> LibraryScreen(vm, upload)
                        Dest.Store -> StoreScreen(vm)
                        Dest.Editor -> EditorScreen(vm)
                        Dest.Setup -> SetupScreen(vm)
                        Dest.Settings -> SettingsScreen(vm)
                    }
                }
            }
        }
    }
}

// ---- shared pieces --------------------------------------------------------------------------

@Composable
fun QCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}

@Composable
fun ScreenColumn(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier.widthIn(max = 920.dp).fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                if (subtitle != null) Muted(subtitle)
            }
            content()
        }
    }
}

@Composable
fun Muted(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        style = MaterialTheme.typography.bodyMedium,
    )
}

@Composable
fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
}

@Composable
fun StatusPill(connected: Boolean) {
    val c = if (connected) Connected else MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = 0.14f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(c))
        Spacer(Modifier.width(8.dp))
        Text(if (connected) "Connected" else "Not connected", color = c, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun GameIcon(pkg: String?, size: Dp) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        pkg?.let { p ->
            runCatching { ctx.packageManager.getApplicationIcon(p).toBitmap(128, 128).asImageBitmap() }.getOrNull()
        }
    }
    Box(Modifier.size(size).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize())
    }
}

@Composable
fun GamePicker(games: List<GameInfo>, onPick: (GameInfo) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose a game") },
        text = {
            Column {
                OutlinedTextField(
                    q, { q = it },
                    label = { Text("Search") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(games.filter { it.label.contains(q, true) || it.pkg.contains(q, true) }, key = { it.pkg }) { g ->
                        Column(Modifier.fillMaxWidth().clickable { onPick(g) }.padding(vertical = 10.dp)) {
                            Text(g.label, fontWeight = FontWeight.SemiBold)
                            Muted(g.pkg)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun ConfirmRemove(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Remove all mods?") },
        text = { Text("QuestForge puts back every file it changed in this game, using the backups it saved before applying.") },
        confirmButton = { TextButton(onClick = { onConfirm(); onDismiss() }) { Text("Remove all mods") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ---- home -----------------------------------------------------------------------------------

@Composable
fun HomeScreen(vm: AppViewModel, go: (Dest) -> Unit, upload: () -> Unit) {
    var picking by remember { mutableStateOf(false) }
    val game = vm.games.firstOrNull { it.pkg == vm.selectedPkg }
    val on = vm.mods.count { it.enabled }

    ScreenColumn("QuestForge", "Mod manager for Meta Quest") {
        Row { StatusPill(vm.connected) }

        QCard {
            SectionTitle("Jump in")
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                GameIcon(vm.selectedPkg, 56.dp)
                Column(Modifier.weight(1f)) {
                    Text(
                        game?.label ?: "No game selected",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Muted(vm.selectedPkg ?: "Choose the game you want to mod")
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { vm.play() }, enabled = vm.selectedPkg != null) {
                    Icon(Icons.Filled.PlayArrow, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Play")
                }
                OutlinedButton(onClick = { picking = true }) { Text("Change game") }
            }
        }

        QCard {
            SectionTitle("Library")
            Muted(
                if (vm.mods.isEmpty()) "No mods yet. Upload a zip or browse the store."
                else "${vm.mods.size} mods, $on turned on",
            )
            vm.mods.take(3).forEach { m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Switch(checked = m.enabled, onCheckedChange = { vm.toggleMod(m.id, it) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = upload) { Text("Upload mods") }
                OutlinedButton(onClick = { go(Dest.Store) }) { Text("Browse mods") }
                if (vm.mods.isNotEmpty()) TextButton(onClick = { go(Dest.Library) }) { Text("Open library") }
            }
        }

        QCard {
            SectionTitle("Wireless debugging")
            Muted(
                if (vm.connected) "QuestForge can reach your games' data folders."
                else "Pair once in Setup so QuestForge can reach your games' data folders.",
            )
            if (!vm.connected) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { go(Dest.Setup) }) { Text("Open setup") }
                    OutlinedButton(onClick = { vm.autoConnect() }) { Text("Reconnect") }
                }
            }
        }
    }

    if (picking) {
        GamePicker(vm.games, onPick = { vm.selectGame(it.pkg); picking = false }, onDismiss = { picking = false })
    }
}

// ---- library --------------------------------------------------------------------------------

@Composable
fun LibraryScreen(vm: AppViewModel, upload: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    val conflicts = findConflicts(vm.mods)
    val canApply = vm.connected && vm.selectedPkg != null && vm.mods.any { it.enabled && it.target == vm.selectedPkg }

    ScreenColumn("Mods", "Turn mods on, then apply them to the game") {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = upload) { Text("Upload mods") }
            OutlinedButton(onClick = { vm.refreshMods() }) { Text("Refresh") }
        }
        if (conflicts.isNotEmpty()) {
            QCard {
                SectionTitle("Conflicts")
                conflicts.forEach { (path, names) ->
                    Muted("$path is changed by ${names.joinToString()}. The most recently added mod wins.")
                }
            }
        }
        if (vm.mods.isEmpty()) {
            QCard {
                SectionTitle("Nothing here yet")
                Muted("Upload a mod zip, or add a store address in Settings and browse mods.")
            }
        }
        vm.mods.forEach { m ->
            QCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            m.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        val by = listOf(m.version, m.author).filter { it.isNotBlank() }.joinToString(" by ")
                        if (by.isNotBlank()) Muted(by)
                    }
                    Switch(checked = m.enabled, onCheckedChange = { vm.toggleMod(m.id, it) })
                    IconButton(onClick = { vm.deleteMod(m.id) }) { Icon(Icons.Filled.Delete, "Delete ${m.name}") }
                }
                if (m.description.isNotBlank()) Muted(m.description)
                Muted(
                    "${m.files.size} files for ${m.target}" +
                        if (m.target != vm.selectedPkg) ". Not the selected game." else "",
                )
            }
        }
        if (!vm.connected) Muted("Connect in Setup to apply mods.")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { vm.applyMods() }, enabled = canApply) { Text("Apply mods") }
            OutlinedButton(
                onClick = { confirm = true },
                enabled = vm.connected && vm.selectedPkg != null,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            ) { Text("Remove all mods") }
        }
    }
    if (confirm) ConfirmRemove(onConfirm = { vm.restoreAll() }, onDismiss = { confirm = false })
}

// ---- store ----------------------------------------------------------------------------------

@Composable
fun StoreScreen(vm: AppViewModel) {
    ScreenColumn("Store", "Mods from your store address") {
        QCard {
            Muted(if (vm.storeUrl.isBlank()) "No store address yet. Add one in Settings." else vm.storeUrl)
            Button(onClick = { vm.loadStore() }, enabled = vm.storeUrl.isNotBlank()) {
                Icon(Icons.Filled.Refresh, null)
                Spacer(Modifier.width(6.dp))
                Text("Refresh store")
            }
        }
        vm.storeItems.forEach { item ->
            QCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(item.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        val by = listOf(item.version, item.author).filter { it.isNotBlank() }.joinToString(" by ")
                        if (by.isNotBlank()) Muted(by)
                        if (item.description.isNotBlank()) Muted(item.description)
                    }
                    Button(onClick = { vm.installFromStore(item) }) { Text("Install") }
                }
            }
        }
    }
}

// ---- editor ---------------------------------------------------------------------------------

@Composable
fun EditorScreen(vm: AppViewModel) {
    val ed = vm.editor
    if (ed == null) FileListScreen(vm) else FileEditorScreen(vm, ed)
}

@Composable
private fun FileListScreen(vm: AppViewModel) {
    ScreenColumn("Editor", "Change saves and settings in the game's data folder") {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { vm.scanFiles() }, enabled = vm.selectedPkg != null) { Text("Scan game files") }
        }
        if (vm.selectedPkg == null) Muted("Pick a game on the Home tab first.")
        else if (vm.editorFiles.isEmpty()) Muted("Scan to list the save and config files this game keeps on the headset.")
        vm.editorFiles.forEach { path ->
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column(Modifier.fillMaxWidth().clickable { vm.openFile(path) }.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Text(path.substringAfterLast('/'), fontWeight = FontWeight.Medium)
                    Muted(path.removePrefix("/sdcard/Android/data/"))
                }
            }
        }
    }
}

@Composable
private fun FileEditorScreen(vm: AppViewModel, ed: EditorState) {
    var query by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier.widthIn(max = 920.dp).fillMaxSize().padding(horizontal = 24.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.closeEditor() }) { Icon(Icons.Filled.ArrowBack, "Back") }
                Column(Modifier.weight(1f)) {
                    Text(
                        ed.path.substringAfterLast('/'),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                    )
                    Muted(ed.path.removePrefix("/sdcard/Android/data/"))
                }
            }
            if (ed.jsonCapable) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !ed.rawMode,
                        onClick = { if (!ed.parseFields()) vm.toast("That text isn't valid JSON yet") },
                        label = { Text("Fields") },
                    )
                    FilterChip(selected = ed.rawMode, onClick = { ed.enterRaw() }, label = { Text("Raw text") })
                }
            }
            if (ed.rawMode) {
                OutlinedTextField(
                    ed.raw, { ed.raw = it },
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                )
            } else {
                OutlinedTextField(
                    query, { query = it },
                    label = { Text("Search fields") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                val shown = ed.fields.withIndex().filter { query.isBlank() || it.value.label.contains(query, true) }
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(shown, key = { it.index }) { (i, f) ->
                        FieldRow(f) { ed.fields[i] = f.copy(value = it) }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { vm.saveEditor() }) { Text("Save to game") }
                OutlinedButton(onClick = { vm.revertEditor() }) { Text("Revert to original") }
            }
        }
    }
}

@Composable
private fun FieldRow(f: JsonField, onChange: (String) -> Unit) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(Modifier.weight(1f)) {
                Text(f.path.last().toString(), fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (f.path.size > 1) Muted(f.label)
            }
            if (f.kind == Kind.Bool) {
                Switch(checked = f.value == "true", onCheckedChange = { onChange(it.toString()) })
            } else {
                OutlinedTextField(f.value, onChange, Modifier.width(220.dp), singleLine = true)
            }
        }
    }
}

// ---- setup ----------------------------------------------------------------------------------

@Composable
private fun StepHeader(n: Int, title: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
            Modifier.size(28.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Text(n.toString(), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        }
        SectionTitle(title)
    }
}

@Composable
fun SetupScreen(vm: AppViewModel) {
    var host by rememberSaveable { mutableStateOf("127.0.0.1") }
    var pairPort by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("") }
    var connectPort by rememberSaveable { mutableStateOf("") }

    ScreenColumn("Setup", "Pair once, then QuestForge reconnects on its own") {
        QCard {
            StepHeader(1, "Turn on Developer Mode")
            Muted("In the Meta Horizon phone app, open Devices, pick your headset, then Headset Settings, then Developer Mode.")
        }
        QCard {
            StepHeader(2, "Turn on Wireless debugging")
            Muted("On the headset, open Settings, System, Developer, and switch on Wireless debugging. The headset has to be on Wi-Fi. Menu names shift a little between OS versions.")
        }
        QCard {
            StepHeader(3, "Pair this app")
            Muted("Tap Pair device with pairing code on the Wireless debugging screen. Keep that popup open, then type its port and code here.")
            OutlinedTextField(host, { host = it }, label = { Text("Host") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    pairPort, { pairPort = it.filter(Char::isDigit) },
                    label = { Text("Pairing port") }, singleLine = true, modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    code, { code = it.filter(Char::isDigit).take(6) },
                    label = { Text("6-digit code") }, singleLine = true, modifier = Modifier.weight(1f),
                )
            }
            Button(onClick = { vm.pair(host, pairPort, code) }) { Text("Pair") }
        }
        QCard {
            StepHeader(4, "Connect")
            Muted("Enter the port shown beside IP address and port on the Wireless debugging screen, or let the app find it.")
            OutlinedTextField(
                connectPort, { connectPort = it.filter(Char::isDigit) },
                label = { Text("Connect port") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { vm.connect(host, connectPort) }) { Text("Connect") }
                OutlinedButton(onClick = { vm.autoConnect() }) { Text("Auto-connect") }
                StatusPill(vm.connected)
            }
        }
        QCard {
            SectionTitle("Log")
            if (vm.logLines.isEmpty()) Muted("Nothing yet.")
            else vm.logLines.takeLast(14).forEach {
                Text(
                    it,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

// ---- settings -------------------------------------------------------------------------------

@Composable
private fun Swatch(brush: Brush, selected: Boolean, label: String, onClick: () -> Unit) {
    val ring = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outlineVariant
    Box(
        Modifier.size(36.dp).clip(CircleShape).background(brush, CircleShape)
            .border(if (selected) 3.dp else 1.dp, ring, CircleShape)
            .semantics { contentDescription = label }
            .clickable(onClick = onClick),
    )
}

@Composable
fun SettingsScreen(vm: AppViewModel) {
    var confirm by remember { mutableStateOf(false) }

    ScreenColumn("Settings", "Make it yours") {
        QCard {
            SectionTitle("Appearance")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.values().forEach { m ->
                    FilterChip(
                        selected = vm.theme.mode == m,
                        onClick = { vm.updateTheme(vm.theme.copy(mode = m)) },
                        label = { Text(m.name) },
                    )
                }
            }
            Muted("Accent colour")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Accents.forEachIndexed { i, a ->
                    Swatch(Brush.linearGradient(listOf(a.color, a.color)), vm.theme.accent == i, a.name) {
                        vm.updateTheme(vm.theme.copy(accent = i))
                    }
                }
                Swatch(
                    Brush.sweepGradient(
                        listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red),
                    ),
                    vm.theme.accent == RGB_ACCENT,
                    "Animated RGB",
                ) { vm.updateTheme(vm.theme.copy(accent = RGB_ACCENT)) }
            }
            if (vm.theme.accent == RGB_ACCENT) {
                Muted("RGB speed")
                Slider(
                    value = vm.theme.rgbSpeed,
                    onValueChange = { vm.updateTheme(vm.theme.copy(rgbSpeed = it)) },
                    valueRange = 0.25f..3f,
                )
            }
        }
        QCard {
            SectionTitle("Store")
            Muted("Point QuestForge at a JSON index of mod zips. See the README for the format.")
            OutlinedTextField(
                vm.storeUrl, { vm.updateStoreUrl(it) },
                label = { Text("Store address (https)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        QCard {
            SectionTitle("Good to know")
            Muted("QuestForge changes files in a game's data and OBB folders on your own headset, and saves a backup of each file first. It can't change anything a game keeps on its servers, and online games can ban accounts for modified files. Stick to offline games or ones whose developers welcome mods.")
            OutlinedButton(
                onClick = { confirm = true },
                enabled = vm.connected && vm.selectedPkg != null,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            ) { Text("Remove all mods") }
        }
    }
    if (confirm) ConfirmRemove(onConfirm = { vm.restoreAll() }, onDismiss = { confirm = false })
}
