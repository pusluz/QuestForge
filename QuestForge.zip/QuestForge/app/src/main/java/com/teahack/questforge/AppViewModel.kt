package com.teahack.questforge

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class GameInfo(val pkg: String, val label: String)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("questforge", Context.MODE_PRIVATE)
    private val repo = ModRepository(app)
    private val adbJob = viewModelScope.async(Dispatchers.IO) { QuestAdb(app) }
    private suspend fun adb(): QuestAdb = adbJob.await()
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val logLines = mutableStateListOf<String>()

    var theme by mutableStateOf(
        ThemeConfig(
            mode = ThemeMode.values().getOrElse(prefs.getInt("mode", 1)) { ThemeMode.Dark },
            accent = prefs.getInt("accent", 0),
            rgbSpeed = prefs.getFloat("rgb_speed", 1f),
        ),
    )
        private set
    var selectedPkg by mutableStateOf(prefs.getString("game", null))
        private set
    var connected by mutableStateOf(false)
        private set
    var busy by mutableStateOf<String?>(null)
        private set
    var games by mutableStateOf<List<GameInfo>>(emptyList())
        private set
    var mods by mutableStateOf<List<Mod>>(emptyList())
        private set
    var storeUrl by mutableStateOf(prefs.getString("store", "") ?: "")
        private set
    var storeItems by mutableStateOf<List<StoreItem>>(emptyList())
        private set
    var editorFiles by mutableStateOf<List<String>>(emptyList())
        private set
    var editor by mutableStateOf<EditorState?>(null)
        private set

    init {
        refreshGames()
        refreshMods()
        if (prefs.getBoolean("paired", false)) autoConnect(silent = true)
    }

    // ---- helpers -------------------------------------------------------------------------

    fun toast(msg: String) {
        messages.tryEmit(msg)
    }

    private fun log(msg: String) {
        logLines.add("${clock.format(Date())}  $msg")
        while (logLines.size > 200) logLines.removeAt(0)
    }

    private fun launchBusy(label: String, block: suspend () -> Unit) = viewModelScope.launch {
        busy = label
        try {
            block()
        } catch (e: Throwable) {
            val why = e.message ?: e.javaClass.simpleName
            log("Error: $why")
            toast(why)
        } finally {
            busy = null
            runCatching { connected = adb().isConnected() }
        }
    }

    private fun requireConnection(): Boolean {
        if (!connected) toast("Connect over wireless debugging first. Open the Setup tab.")
        return connected
    }

    // ---- theme, settings -----------------------------------------------------------------

    fun updateTheme(cfg: ThemeConfig) {
        prefs.edit()
            .putInt("mode", cfg.mode.ordinal)
            .putInt("accent", cfg.accent)
            .putFloat("rgb_speed", cfg.rgbSpeed)
            .apply()
        theme = cfg
    }

    fun updateStoreUrl(url: String) {
        prefs.edit().putString("store", url).apply()
        storeUrl = url
    }

    // ---- games ---------------------------------------------------------------------------

    fun refreshGames() {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val pm = ctx.packageManager
            val list = pm.getInstalledApplications(0)
                .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != ctx.packageName }
                .map { GameInfo(it.packageName, it.loadLabel(pm).toString()) }
                .sortedBy { it.label.lowercase() }
            withContext(Dispatchers.Main) { games = list }
        }
    }

    fun selectGame(pkg: String) {
        prefs.edit().putString("game", pkg).apply()
        selectedPkg = pkg
        editor = null
        editorFiles = emptyList()
    }

    fun play() {
        val pkg = selectedPkg ?: return toast("Pick a game first")
        val ctx = getApplication<Application>()
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            return
        }
        if (!connected) return toast("Couldn't launch it from here. Open it from your library.")
        viewModelScope.launch {
            adb().sh("monkey -p ${shq(pkg)} -c android.intent.category.LAUNCHER 1")
        }
    }

    // ---- wireless debugging --------------------------------------------------------------

    fun pair(host: String, port: String, code: String) = launchBusy("Pairing…") {
        val p = port.trim().toIntOrNull() ?: return@launchBusy toast("Enter the pairing port from the popup")
        if (code.length != 6) return@launchBusy toast("The pairing code has 6 digits")
        adb().pairWith(host.trim().ifBlank { "127.0.0.1" }, p, code)
            .onSuccess {
                prefs.edit().putBoolean("paired", true).apply()
                log("Paired. Next, connect.")
                toast("Paired")
            }
            .onFailure {
                log("Pairing failed: ${it.message}")
                toast("Pairing failed")
            }
    }

    fun connect(host: String, port: String) = launchBusy("Connecting…") {
        val p = port.trim().toIntOrNull() ?: return@launchBusy toast("Enter the connect port")
        adb().connectTo(host.trim().ifBlank { "127.0.0.1" }, p)
            .onSuccess {
                connected = true
                log("Connected")
                toast("Connected")
            }
            .onFailure {
                log("Connect failed: ${it.message}")
                toast("Couldn't connect")
            }
    }

    fun autoConnect(silent: Boolean = false) = launchBusy("Connecting…") {
        adb().autoConnectTls()
            .onSuccess {
                connected = true
                log("Connected")
                if (!silent) toast("Connected")
            }
            .onFailure {
                log("Auto-connect failed: ${it.message}")
                if (!silent) toast("Couldn't auto-connect")
            }
    }

    // ---- mods ----------------------------------------------------------------------------

    fun refreshMods() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = repo.list()
            withContext(Dispatchers.Main) { mods = list }
        }
    }

    fun toggleMod(id: String, on: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.setEnabled(id, on)
            val list = repo.list()
            withContext(Dispatchers.Main) { mods = list }
        }
    }

    fun deleteMod(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.delete(id)
            val list = repo.list()
            withContext(Dispatchers.Main) { mods = list }
        }
    }

    fun importMod(uri: Uri) = launchBusy("Importing…") {
        val ctx = getApplication<Application>()
        val mod = withContext(Dispatchers.IO) {
            val name = runCatching {
                ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                }
            }.getOrNull() ?: "mod.zip"
            val stream = ctx.contentResolver.openInputStream(uri) ?: error("Couldn't open that file.")
            stream.use { repo.import(it, name, selectedPkg.orEmpty()) }
        }
        refreshMods()
        toast("Imported ${mod.name}")
    }

    fun applyMods() = launchBusy("Applying mods…") {
        val pkg = selectedPkg ?: return@launchBusy toast("Pick a game first")
        if (!requireConnection()) return@launchBusy
        val n = Deployer(getApplication<Application>(), adb(), repo).applyAll(pkg, mods) { log(it) }
        toast("Applied $n files")
    }

    fun restoreAll() = launchBusy("Restoring…") {
        val pkg = selectedPkg ?: return@launchBusy toast("Pick a game first")
        if (!requireConnection()) return@launchBusy
        val ok = Deployer(getApplication<Application>(), adb(), repo).restore(pkg) { log(it) }
        toast(if (ok) "Original files restored" else "Some files couldn't be restored. See the Setup log.")
    }

    // ---- store ---------------------------------------------------------------------------

    fun loadStore() = launchBusy("Loading store…") {
        val url = storeUrl.trim()
        if (!url.startsWith("https://")) return@launchBusy toast("Add an https store address in Settings")
        storeItems = StoreClient.fetchIndex(url)
        if (storeItems.isEmpty()) toast("That store has no mods yet")
    }

    fun installFromStore(item: StoreItem) = launchBusy("Downloading ${item.name}…") {
        val pkg = selectedPkg.orEmpty()
        val mod = withContext(Dispatchers.IO) {
            StoreClient.open(item.url).use { repo.import(it, item.name + ".zip", pkg) }
        }
        refreshMods()
        toast("Installed ${mod.name}")
    }

    // ---- editor --------------------------------------------------------------------------

    private fun dataRoot(pkg: String) = "/sdcard/Android/data/$pkg"
    private fun editBackup(pkg: String, path: String) =
        "/sdcard/QuestForge/backups/$pkg/editor/" + path.removePrefix(dataRoot(pkg) + "/")

    fun scanFiles() = launchBusy("Scanning…") {
        val pkg = selectedPkg ?: return@launchBusy toast("Pick a game first")
        if (!requireConnection()) return@launchBusy
        val cmd = """find ${shq(dataRoot(pkg))} -type f ! -path '*/cache/*' \( -iname '*.json' -o -iname '*.cfg' -o -iname '*.ini' -o -iname '*.txt' -o -iname '*.xml' -o -iname '*.dat' \) 2>/dev/null | head -300"""
        val r = adb().sh(cmd)
        editorFiles = r.out.lines().map { it.trim() }.filter { it.startsWith("/") }.sorted()
        if (editorFiles.isEmpty()) toast("No readable files found. The game may keep its saves elsewhere.")
    }

    fun openFile(path: String) = launchBusy("Opening…") {
        val a = adb()
        val size = a.sh("wc -c < ${shq(path)}").out.trim().toLongOrNull() ?: -1L
        if (size < 0 || size > 2_000_000) return@launchBusy toast("That file is too large to edit here")
        val text = a.sh("cat ${shq(path)}").out
        if (text.any { it == '\u0000' }) return@launchBusy toast("That file is binary and can't be edited as text")
        editor = EditorState(path, text)
    }

    fun closeEditor() {
        editor = null
    }

    fun saveEditor() = launchBusy("Saving…") {
        val ed = editor ?: return@launchBusy
        val pkg = selectedPkg ?: return@launchBusy
        if (!requireConnection()) return@launchBusy
        val text = ed.render() ?: return@launchBusy toast("One of the number fields isn't a number")
        val tmp = withContext(Dispatchers.IO) {
            val dir = getApplication<Application>().getExternalFilesDir("staging") ?: error("No storage available.")
            dir.mkdirs()
            File(dir, "edit.tmp").also { it.writeText(text) }
        }
        val bak = editBackup(pkg, ed.path)
        val a = adb()
        a.sh("am force-stop ${shq(pkg)}")
        val r = a.sh(
            "mkdir -p ${shq(bak.substringBeforeLast('/'))}; " +
                "if [ -e ${shq(bak)} ] || cp -f ${shq(ed.path)} ${shq(bak)}; then " +
                "cp -f ${shq(tmp.absolutePath)} ${shq(ed.path)} && echo OK; else echo BACKUPFAIL; fi",
        )
        if (r.out.lines().any { it.trim() == "OK" }) {
            log("Saved ${ed.path}")
            toast("Saved. The original is kept for Revert.")
        } else {
            toast("Save failed: ${r.out.take(100)}")
        }
    }

    fun revertEditor() = launchBusy("Reverting…") {
        val ed = editor ?: return@launchBusy
        val pkg = selectedPkg ?: return@launchBusy
        if (!requireConnection()) return@launchBusy
        val bak = editBackup(pkg, ed.path)
        val a = adb()
        a.sh("am force-stop ${shq(pkg)}")
        val r = a.sh("if [ -e ${shq(bak)} ]; then cp -f ${shq(bak)} ${shq(ed.path)} && echo OK; else echo NOBACKUP; fi")
        val lines = r.out.lines().map { it.trim() }
        when {
            "OK" in lines -> {
                editor = EditorState(ed.path, a.sh("cat ${shq(ed.path)}").out)
                toast("Original restored")
            }
            "NOBACKUP" in lines -> toast("Nothing to revert yet. You haven't saved this file.")
            else -> toast("Revert failed")
        }
    }
}
