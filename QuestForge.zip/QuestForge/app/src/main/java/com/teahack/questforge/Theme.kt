package com.teahack.questforge

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance

enum class ThemeMode { Light, Dark, Oled }

data class AccentOption(val name: String, val color: Color)

val Accents = listOf(
    AccentOption("Ocean", Color(0xFF4C8DFF)),
    AccentOption("Ice", Color(0xFF5CD6F0)),
    AccentOption("Mint", Color(0xFF2ED3A5)),
    AccentOption("Gold", Color(0xFFF5C451)),
    AccentOption("Sunset", Color(0xFFFF8A4C)),
    AccentOption("Rose", Color(0xFFFF5C8A)),
    AccentOption("Violet", Color(0xFF9B7BFF)),
    AccentOption("Slate", Color(0xFF9AA4B2)),
)

/** Index that means "animated RGB" instead of one of [Accents]. */
const val RGB_ACCENT = 8

data class ThemeConfig(
    val mode: ThemeMode = ThemeMode.Dark,
    val accent: Int = 0,
    val rgbSpeed: Float = 1f,
)

@Composable
fun QuestForgeTheme(cfg: ThemeConfig, content: @Composable () -> Unit) {
    val hue = if (cfg.accent == RGB_ACCENT) {
        val transition = rememberInfiniteTransition(label = "rgb")
        val h by transition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                tween((14_000 / cfg.rgbSpeed.coerceIn(0.2f, 4f)).toInt(), easing = LinearEasing),
            ),
            label = "hue",
        )
        h
    } else {
        0f
    }
    val accent = if (cfg.accent == RGB_ACCENT) {
        Color.hsv(hue, 0.62f, 1f)
    } else {
        Accents[cfg.accent.coerceIn(0, Accents.lastIndex)].color
    }
    val onAccent = if (accent.luminance() > 0.4f) Color(0xFF0F1216) else Color.White
    MaterialTheme(
        colorScheme = palette(cfg.mode, accent, onAccent),
        typography = Typography(),
        content = content,
    )
}

private fun palette(mode: ThemeMode, accent: Color, onAccent: Color): ColorScheme {
    val bg: Color
    val surface: Color
    val variant: Color
    val outline: Color
    val outlineVariant: Color
    val text: Color
    val muted: Color
    when (mode) {
        ThemeMode.Light -> {
            bg = Color(0xFFF3F4F6); surface = Color.White; variant = Color(0xFFE9EBEF)
            outline = Color(0xFFB8BEC8); outlineVariant = Color(0xFFDDE1E7)
            text = Color(0xFF16181C); muted = Color(0xFF5B6470)
        }
        ThemeMode.Dark -> {
            bg = Color(0xFF16181C); surface = Color(0xFF1D2025); variant = Color(0xFF262A31)
            outline = Color(0xFF3A404A); outlineVariant = Color(0xFF2B3038)
            text = Color(0xFFE8EAED); muted = Color(0xFF9BA3AF)
        }
        ThemeMode.Oled -> {
            bg = Color.Black; surface = Color(0xFF0A0B0D); variant = Color(0xFF14161A)
            outline = Color(0xFF2A2E35); outlineVariant = Color(0xFF1B1E23)
            text = Color(0xFFE8EAED); muted = Color(0xFF9BA3AF)
        }
    }
    val base = if (mode == ThemeMode.Light) lightColorScheme() else darkColorScheme()
    return base.copy(
        primary = accent,
        onPrimary = onAccent,
        primaryContainer = accent.copy(alpha = 0.18f).compositeOver(surface),
        onPrimaryContainer = accent,
        secondary = accent,
        secondaryContainer = accent.copy(alpha = 0.2f).compositeOver(surface),
        onSecondaryContainer = accent,
        background = bg,
        onBackground = text,
        surface = surface,
        onSurface = text,
        surfaceVariant = variant,
        onSurfaceVariant = muted,
        surfaceContainerHigh = surface,
        outline = outline,
        outlineVariant = outlineVariant,
    )
}
