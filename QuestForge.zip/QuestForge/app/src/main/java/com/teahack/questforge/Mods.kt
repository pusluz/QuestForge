package com.teahack.questforge

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.zip.ZipInputStream

/**
 * A mod is a zip with this layout:
 *   mod.json            optional: name, version, author, description, target (package id)
 *   data/<path>         goes to /sdcard/Android/data/<target>/<path>
 *   obb/<path>          goes to /sdcard/Android/obb/<target>/<path>
 */
data class Mod(
    val id: String,
    val name: String,
    val version: String,
    val author: String,
    val description: String,
    val target: String,
    val files: List<String>,
    val enabled: Boolean,
    val added: Long,
)

private val PKG_REGEX = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")

class ModRepository(private val ctx: Context) {
    // External app dir, so the adb shell user can read the extracted files.
    val root: File = (ctx.getExternalFilesDir("mods") ?: File(ctx.filesDir, "mods")).also { it.mkdirs() }

    fun list(): List<Mod> =
        root.listFiles { f -> f.isDirectory }.orEmpty().mapNotNull { read(it) }.sortedBy { it.added }

    private fun read(dir: File): Mod? = runCatching {
        val j = JSONObject(File(dir, "mod.json").readText())
        val arr = j.getJSONArray("files")
        Mod(
            id = dir.name,
            name = j.optString("name", dir.name),
            version = j.optString("version", ""),
            author = j.optString("author", ""),
            description = j.optString("description", ""),
            target = j.getString("target"),
            files = List(arr.length()) { arr.getString(it) },
            enabled = j.optBoolean("enabled", false),
            added = j.optLong("added", 0L),
        )
    }.getOrNull()

    private fun write(m: Mod) {
        val j = JSONObject()
            .put("name", m.name)
            .put("version", m.version)
            .put("author", m.author)
            .put("description", m.description)
            .put("target", m.target)
            .put("files", JSONArray(m.files))
            .put("enabled", m.enabled)
            .put("added", m.added)
        File(root, "${m.id}/mod.json").writeText(j.toString(2))
    }

    fun setEnabled(id: String, enabled: Boolean) {
        read(File(root, id))?.let { write(it.copy(enabled = enabled)) }
    }

    fun delete(id: String) {
        File(root, id).deleteRecursively()
    }

    private fun sanitize(path: String): String? {
        val parts = path.split('/').filter { it.isNotEmpty() && it != "." }
        if (parts.size < 2 || parts.any { it == ".." || it.contains('\u0000') }) return null
        return parts.joinToString("/")
    }

    fun import(input: InputStream, fileName: String, defaultTarget: String): Mod {
        val id = UUID.randomUUID().toString().take(8)
        val dir = File(root, id)
        val content = File(dir, "content").also { it.mkdirs() }
        var meta = JSONObject()
        val files = mutableListOf<String>()
        try {
            ZipInputStream(input.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    val name = entry.name.replace('\\', '/').trimStart('/')
                    if (!entry.isDirectory) {
                        if (name == "mod.json") {
                            meta = JSONObject(String(zip.readBytes(), Charsets.UTF_8))
                        } else if (name.startsWith("data/") || name.startsWith("obb/")) {
                            val safe = sanitize(name)
                            if (safe != null) {
                                val out = File(content, safe)
                                out.parentFile?.mkdirs()
                                out.outputStream().use { o -> zip.copyTo(o) }
                                files += safe
                            }
                        }
                    }
                    zip.closeEntry()
                }
            }
            require(files.isNotEmpty()) { "That zip has no data/ or obb/ files. See the README for the mod layout." }
            val target = meta.optString("target").ifBlank { defaultTarget }
            require(PKG_REGEX.matches(target)) { "Pick a game first, or set \"target\" in mod.json." }
            val mod = Mod(
                id = id,
                name = meta.optString("name").ifBlank { fileName.removeSuffix(".zip") },
                version = meta.optString("version"),
                author = meta.optString("author"),
                description = meta.optString("description"),
                target = target,
                files = files.sorted(),
                enabled = false,
                added = System.currentTimeMillis(),
            )
            write(mod)
            return mod
        } catch (t: Throwable) {
            dir.deleteRecursively()
            throw t
        }
    }
}

/** Files that more than one enabled mod wants to change (most recently added mod wins). */
fun findConflicts(mods: List<Mod>): List<Pair<String, List<String>>> =
    mods.filter { it.enabled }.groupBy { it.target }.flatMap { (_, group) ->
        group.flatMap { m -> m.files.map { f -> f to m.name } }
            .groupBy({ it.first }, { it.second })
            .filter { it.value.size > 1 }
            .map { (path, names) -> path to names }
    }

/** Applies enabled mods to a game through adb and keeps backups so everything can be undone. */
class Deployer(
    private val ctx: Context,
    private val adb: QuestAdb,
    private val repo: ModRepository,
) {
    // Backups live on shared storage so they survive uninstalling QuestForge.
    private val backups = "/sdcard/QuestForge/backups"

    private fun abs(pkg: String, rel: String): String =
        if (rel.startsWith("obb/")) "/sdcard/Android/obb/$pkg/${rel.removePrefix("obb/")}"
        else "/sdcard/Android/data/$pkg/${rel.removePrefix("data/")}"

    private fun stateFile(pkg: String) = File(ctx.filesDir, "applied_$pkg.json")

    suspend fun applyAll(pkg: String, mods: List<Mod>, log: (String) -> Unit): Int =
        withContext(Dispatchers.IO) {
            if (!restore(pkg, log)) {
                log("Stopped: the previous apply couldn't be cleaned up first.")
                return@withContext 0
            }
            adb.sh("am force-stop ${shq(pkg)}")
            val plan = LinkedHashMap<String, Pair<Mod, File>>()
            mods.filter { it.enabled && it.target == pkg }.sortedBy { it.added }.forEach { m ->
                m.files.forEach { rel -> plan[rel] = m to File(repo.root, "${m.id}/content/$rel") }
            }
            val state = JSONArray()
            var done = 0
            for ((rel, entry) in plan) {
                val (mod, src) = entry
                val dst = abs(pkg, rel)
                val bak = "$backups/$pkg/$rel"
                val script = "mkdir -p ${shq(dst.substringBeforeLast('/'))}; " +
                    "if [ -e ${shq(dst)} ]; then " +
                    "mkdir -p ${shq(bak.substringBeforeLast('/'))}; " +
                    "if [ -e ${shq(bak)} ] || cp -f ${shq(dst)} ${shq(bak)}; then " +
                    "cp -f ${shq(src.absolutePath)} ${shq(dst)} && echo EXISTED_OK; " +
                    "else echo BACKUPFAIL; fi; " +
                    "else cp -f ${shq(src.absolutePath)} ${shq(dst)} && echo NEW_OK; fi"
                val r = adb.sh(script)
                val lines = r.out.lines().map { it.trim() }
                when {
                    "EXISTED_OK" in lines -> {
                        state.put(JSONObject().put("rel", rel).put("existed", true))
                        done++
                        log("Applied $rel (${mod.name})")
                    }
                    "NEW_OK" in lines -> {
                        state.put(JSONObject().put("rel", rel).put("existed", false))
                        done++
                        log("Added $rel (${mod.name})")
                    }
                    else -> log("Failed: $rel. ${r.out.take(100)}")
                }
            }
            stateFile(pkg).writeText(state.toString())
            done
        }

    /** Put every touched file back the way it was. Returns true if nothing is left to undo. */
    suspend fun restore(pkg: String, log: (String) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            val f = stateFile(pkg)
            if (!f.exists()) return@withContext true
            val arr = JSONArray(f.readText())
            var allOk = true
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val rel = e.getString("rel")
                val dst = abs(pkg, rel)
                val bak = "$backups/$pkg/$rel"
                val cmd = if (e.getBoolean("existed")) {
                    "cp -f ${shq(bak)} ${shq(dst)} && echo OK"
                } else {
                    "rm -f ${shq(dst)} && echo OK"
                }
                val r = adb.sh(cmd)
                if ("OK" in r.out.lines().map { it.trim() }) {
                    log("Restored $rel")
                } else {
                    allOk = false
                    log("Couldn't restore $rel")
                }
            }
            if (allOk) f.delete()
            allOk
        }
}

data class StoreItem(
    val id: String,
    val name: String,
    val author: String,
    val version: String,
    val description: String,
    val url: String,
)

/** Reads a JSON index of mods: [{"id","name","author","version","description","url"}] */
object StoreClient {
    fun open(url: String): InputStream {
        require(url.startsWith("https://")) { "Store links must use https." }
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 60_000
        if (c.responseCode !in 200..299) error("The server answered ${c.responseCode}.")
        return c.inputStream
    }

    suspend fun fetchIndex(indexUrl: String): List<StoreItem> = withContext(Dispatchers.IO) {
        val text = open(indexUrl).use { String(it.readBytes(), Charsets.UTF_8) }
        val arr = if (text.trimStart().startsWith("[")) JSONArray(text) else JSONObject(text).getJSONArray("mods")
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            StoreItem(
                id = o.optString("id", i.toString()),
                name = o.getString("name"),
                author = o.optString("author"),
                version = o.optString("version"),
                description = o.optString("description"),
                url = URL(URL(indexUrl), o.getString("url")).toString(),
            )
        }
    }
}
