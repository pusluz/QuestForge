package com.teahack.questforge

import android.content.Context
import android.os.Build
import android.util.Base64
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.ByteArrayInputStream
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date

/** Quote a string for safe use inside a shell command. */
fun shq(s: String): String = "'" + s.replace("'", "'\\''") + "'"

data class ShellResult(val out: String, val code: Int)

/**
 * Talks to the headset's own adbd over Wireless debugging.
 * Pair once with the 6-digit code; the generated key is kept so later connects need no code.
 */
class QuestAdb(context: Context) : AbsAdbConnectionManager() {
    private val appCtx = context.applicationContext
    private val prefs = appCtx.getSharedPreferences("adb_identity", Context.MODE_PRIVATE)
    private val identity: Pair<PrivateKey, Certificate> = loadOrCreateIdentity()

    init {
        setApi(Build.VERSION.SDK_INT)
    }

    override fun getPrivateKey(): PrivateKey = identity.first
    override fun getCertificate(): Certificate = identity.second
    override fun getDeviceName(): String = "QuestForge"

    private fun loadOrCreateIdentity(): Pair<PrivateKey, Certificate> {
        val k = prefs.getString("key", null)
        val c = prefs.getString("cert", null)
        if (k != null && c != null) {
            runCatching {
                val key = KeyFactory.getInstance("RSA")
                    .generatePrivate(PKCS8EncodedKeySpec(Base64.decode(k, Base64.NO_WRAP)))
                val cert = CertificateFactory.getInstance("X.509")
                    .generateCertificate(ByteArrayInputStream(Base64.decode(c, Base64.NO_WRAP)))
                return key to cert
            }
        }
        val gen = KeyPairGenerator.getInstance("RSA")
        gen.initialize(2048, SecureRandom())
        val pair = gen.generateKeyPair()
        val name = X500Name("CN=QuestForge")
        val now = System.currentTimeMillis()
        val builder = JcaX509v3CertificateBuilder(
            name,
            BigInteger.valueOf(now),
            Date(now - 86_400_000L),
            Date(now + 3_650L * 86_400_000L),
            name,
            pair.public,
        )
        val signer = JcaContentSignerBuilder("SHA512withRSA").build(pair.private)
        val cert = JcaX509CertificateConverter().getCertificate(builder.build(signer))
        prefs.edit()
            .putString("key", Base64.encodeToString(pair.private.encoded, Base64.NO_WRAP))
            .putString("cert", Base64.encodeToString(cert.encoded, Base64.NO_WRAP))
            .apply()
        return pair.private to cert
    }

    suspend fun pairWith(host: String, port: Int, code: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val ok: Any? = pair(host, port, code)
                check(ok != false) { "The headset rejected the code. Reopen the pairing popup and try again." }
            }
        }

    suspend fun connectTo(host: String, port: Int): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val ok: Any? = connect(host, port)
                check(ok != false) { "Couldn't connect. Check the port and that Wireless debugging is on." }
            }
        }

    suspend fun autoConnectTls(): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val ok: Any? = connectTls(appCtx, 12_000L)
                check(ok != false) { "Couldn't find the headset's wireless debugging service." }
            }
        }

    /** Run a shell command on the headset and return its output and exit code. */
    suspend fun sh(cmd: String): ShellResult = withContext(Dispatchers.IO) {
        val wrapped = "$cmd; __rc=\$?; echo; echo $MARK\$__rc"
        runCatching { runService("exec:$wrapped", false) }.getOrNull()
            ?: runCatching { runService("shell:$wrapped", true) }.getOrNull()
            ?: ShellResult("No answer from the headset. Is wireless debugging still connected?", -1)
    }

    private fun runService(service: String, fixCrlf: Boolean): ShellResult? {
        val stream = openStream(service)
        try {
            var raw = stream.openInputStream().bufferedReader().readText()
            if (fixCrlf) raw = raw.replace("\r\n", "\n")
            val i = raw.lastIndexOf(MARK)
            if (i < 0) return null
            val code = raw.substring(i + MARK.length).trim().toIntOrNull() ?: -1
            return ShellResult(raw.substring(0, i).removeSuffix("\n"), code)
        } finally {
            runCatching { stream.close() }
        }
    }

    private companion object {
        const val MARK = "__QF_RC="
    }
}
